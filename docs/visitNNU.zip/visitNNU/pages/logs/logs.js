//logs.js
const util = require('../../utils/util.js')
var click = true
Page({
  data: {
    //初始化为南师坐标  地图标记
    latitude: 32.100172,
    longitude: 118.912582,
    hospital: true,
    scale: 16.5,
  },
  /****************************************校 门***************************************** */
  hx_door: function () {

    /*var maps = [32.100172, 118.912582]*/
    this.setData({
      hx_door: true,
      hx_attractions:false,
      hx_canteen: false,
      hx_supermarket: false,
      hx_teach: false,
      hx_hospital: false,
      hx_Sportscenter:false,
      hx_playground: false,
      hx_library: false,
      hx_dorm: false,
      latitude: 32.103544,  /**图书馆 */
      longitude: 118.911670,
      scale: 16,
      markers: [
        /*1号门*/ 
        {
        iconPath: '../images/icon.jpg',
          latitude: 32.100172, 
          longitude: 118.912582,
        width: 20,
        height: 20
      },
      /*3号门*/
        {
          iconPath: '../images/icon.jpg',
          latitude: 32.098281, 
          longitude: 118.906639,
          width: 20,
          height: 20
        },
        /*2号门*/
          {
          iconPath: '../images/icon.jpg',
            latitude: 32.104771,
            longitude: 118.915216
,
          width: 20,
          height: 20
        }
      
      ]
    })
  },
  /****************************************  ? ?景点***************************************** */
  hx_attractions: function () {

    /*var maps = [32.100172, 118.912582]*/
    this.setData({
      hx_door: false,
      hx_attractions:true,
      hx_canteen: false,
      hx_supermarket: false,
      hx_teach: false,
      hx_hospital: false,
      hx_Sportscenter: false,
      hx_playground: false,
      hx_library: false,
      hx_dorm: false,
      latitude: 32.103544,  /**图书馆 */
      longitude: 118.911670,
      scale: 16,
      markers: [
        /*仙鹤观*/
        {
          iconPath: '../images/icon.jpg',
          latitude: 32.100690, 
          longitude: 118.904632,
          width: 20,
          height: 20
        },
        /*仙林宾馆*/
        {
          iconPath: '../images/icon.jpg',
          latitude: 32.108165, 
          longitude: 118.912502,
          width: 20,
          height: 20
        },
        /*栖霞坡*/
        {
          iconPath: '../images/icon.jpg',
          latitude: 32.106784, 
          longitude: 118.911413,
          width: 20,
          height: 20
        },
           /*月亮湾*/
        {
          iconPath: '../images/icon.jpg',
          latitude: 32.100744, 
          longitude: 118.908859,
          width: 20,
          height: 20
        }

      ]
    })
  },
  /****************************************食堂***************************************** */
  hx_canteen: function () {
    this.setData({
      hx_door: false,
      hx_attractions: false,
      hx_canteen: true,
      hx_supermarket: false,
      hx_teach: false,
      hx_hospital: false,
      hx_Sportscenter: false,
      hx_playground: false,
      hx_library: false,
      hx_dorm: false,
      latitude: 32.103544,  /**图书馆 */
      longitude: 118.911670,
      scale: 16,
      markers: [
        /* 西区食堂*/
        {
        iconPath: '../images/icon.jpg',
          latitude: 32.101976, 
          longitude: 118.907642,
        width: 20,
        height: 20
      },
        /* 东区食堂*/
       {
        iconPath: '../images/icon.jpg',
         latitude: 32.106020, 
         longitude: 118.913044,
        width: 20,
        height: 20
      },
       /* 南区食堂*/
       {
          iconPath: '../images/icon.jpg',
         latitude: 32.098400,
         longitude: 118.911531,
          width: 20,
          height: 20
        }

      ]
    })
  },
  /**************************************** 超市***************************************** */
  hx_supermarket: function () {
    this.setData({
      hx_door: false,
      hx_canteen: false,
      hx_attractions: false,
      hx_supermarket: true,
      hx_teach: false,
      hx_hospital: false,
      hx_Sportscenter: false,
      hx_playground: false,
      hx_library: false,
      hx_dorm: false,
      latitude: 32.103544,  /**图书馆 */
      longitude: 118.911670,
      scale: 16,
      markers: [{
        iconPath: '../images/icon.jpg',   //东区超市
        latitude: 32.105916, 
        longitude: 118.914433,
        width: 20,
        height: 20
      }, {
          iconPath: '../images/icon.jpg',   //西区超市
          latitude: 32.101458,
          longitude: 118.908060,
        width: 20,
        height: 20
      }

      ]
    })
  },
  /**************************************** ？？ 教学楼***************************************** */
  hx_teach: function () {
    this.setData({
      hx_door: false,
      hx_attractions: false,
      hx_canteen: false,
      hx_supermarket: false,
      hx_teach: true,
      hx_hospital: false,
      hx_Sportscenter: false,
      hx_playground: false,
      hx_library: false,
      hx_dorm: false,
      latitude: 32.101544,  /**图书馆 */
      longitude: 118.911670,
      scale: 17,
      markers: [{
        iconPath: '../images/icon.jpg',   //学明楼
        latitude: 32.102176,
        longitude: 118.910844,
        width: 20,
        height: 20
      }, {
          iconPath: '../images/icon.jpg',   //学正楼
          latitude: 32.102703,
          longitude: 118.912593,
        width: 20,
        height: 20
      }, {
          iconPath: '../images/icon.jpg',   //学海楼
          latitude: 32.102239,
          longitude: 118.913527,
        width: 20,
        height: 20
      }, {
          iconPath: '../images/icon.jpg',   //化成楼
          latitude: 32.100926,
          longitude: 118.909788,
        width: 20,
        height: 20
      }
      ]
    })
  },

  /****************************************  校医院***************************************** */
  hx_hospital: function () {
    var maps = [32.102280, 118.908226]
    this.setData({
      hx_door: false,
      hx_attractions: false,
      hx_canteen: false,
      hx_supermarket: false,
      hx_teach: false,
      hx_hospital: true,
      hx_Sportscenter: false,
      hx_playground: false,
      hx_library: false,
      hx_dorm: false,
      latitude: maps[0], //经度
      longitude: maps[1], //纬度
      scale: 20,
      markers: [{
        iconPath: '../images/icon.jpg',
        latitude: maps[0],
        longitude: maps[1],
        width: 20,
        height: 20
      }]
    })
  },
  /****************************************  体 育 中心***************************************** */
  hx_Sportscenter: function () {
    this.setData({
      hx_door: false,
      hx_attractions: false,
      hx_canteen: false,
      hx_supermarket: false,
      hx_teach: false,
      hx_hospital: false,
      hx_Sportscenter: true,
      hx_playground: false,
      hx_library: false,
      hx_dorm: false,
      latitude: 32.099408, 
      longitude: 118.906531,
      scale: 19,
      markers: [{
        iconPath: '../images/icon.jpg',
        latitude: 32.099408, /**体育中心 */
        longitude: 118.906531,
        width: 20,
        height: 20
      }]
    })
  },
  /****************************************体 育 场***************************************** */
  hx_playground: function () {
    this.setData({
      hx_door: false,
      hx_attractions: false,
      hx_canteen: false,
      hx_supermarket: false,
      hx_teach: false,
      hx_hospital: false,
      hx_Sportscenter: false,
      hx_playground: true,
      hx_library: false,
      hx_dorm: false,
      latitude: 32.102176,
      longitude: 118.910844,
      scale: 17,
      markers: [{
        iconPath: '../images/icon.jpg',
        latitude: 32.099976,  /**西区运动场 */
        longitude: 118.908151,
        width: 20,
        height: 20
      },
      {
        iconPath: '../images/icon.jpg',
        latitude: 32.103121,
        longitude: 118.914669,   /**东区运动场 */
        width: 20,
        height: 20
      }]
    })
  },
  /****************************************敬 文 图 书 馆***************************************** */
  hx_library: function () {
    this.setData({
      hx_door: false,
      hx_attractions: false,
      hx_canteen: false,
      hx_supermarket: false,
      hx_teach: false,
      hx_hospital: false,
      hx_Sportscenter: false,
      hx_playground: false,
      hx_library: true,
      hx_dorm: false,
      latitude: 32.103544,  /**图书馆 */
      longitude: 118.911670,
      scale: 19,
      markers: [{
        iconPath: '../images/icon.jpg',
        latitude: 32.103544,  /**图书馆 */
        longitude: 118.911670,
        width: 20,
        height: 20
      }]
    })
  },

  /**************************************** 宿 舍***************************************** */
  hx_dorm: function () {
    this.setData({
      hx_door: false,
      hx_attractions: false,
      hx_canteen: false,
      hx_supermarket: false,
      hx_teach: false,
      hx_hospital: false,
      hx_Sportscenter: false,
      hx_playground: false,
      hx_library: false,
      hx_dorm: true,
      latitude: 32.103544,  /**图书馆 */
      longitude: 118.911670,
      scale: 17,
      markers: [{
        iconPath: '../images/icon.jpg',
        latitude: 32.101299,  /**西区学生公寓1 */
        longitude: 118.907926,
        width: 20,
        height: 20
      }, {
          iconPath: '../images/icon.jpg',
          latitude: 32.105420,   /**东区学生公寓2 */
          longitude: 118.914133,
        width: 20,
        height: 20
      }, {
        iconPath: '../images/icon.jpg',
          latitude: 32.099004,   /**南区学生公寓3 */
          longitude: 118.911724,
        width: 20,
        height: 20
      }


      ]
    })
  },
/*  onShow: function () {
    this.setData({
      mapheight: 650  //设置地图高度
    })
    this.setData({
      icon: "∨",
      bootom: 0
    })

  },*/
  onShareAppMessage: function () {
    /**用户点击分享 */
  },
  onLoad: function () {
    this.setData({
      logs: (wx.getStorageSync('logs') || []).map(log => {
        return util.formatTime(new Date(log))
      })
    })
  },
  /**go go go*/
  go: function (e) {
    var id = e.currentTarget.id; //获取id
    switch (id) {
      /*大门*/
      case "door1":
        wx.openLocation({ /*使用微信内置地图查看位置*/
          latitude: 32.100172,
          longitude: 118.912582,
          scale: 25
        })
        break;
      case "door2":
        wx.openLocation({ /*使用微信内置地图查看位置*/
          latitude: 32.104771,
          longitude: 118.915216,
          scale: 25
        })
        break;
      case "door3":
        wx.openLocation({ /*使用微信内置地图查看位置*/
          latitude: 32.098281,
          longitude: 118.906639,
          scale: 25
        })
        break;
    
      /* 仙鹤观
      case "attraction1":
        wx.openLocation({ 
          latitude: 32.098281,
          longitude: 118.906639,
          scale: 25
        })
        break;
         仙林宾馆
      case "attraction2":
        wx.openLocation({ 
          latitude: 32.098281,
          longitude: 118.906639,
          scale: 25
        })
        break;
          栖霞坡
      case "attraction3":
        wx.openLocation({ 
          latitude: 32.098281,
          longitude: 118.906639,
          scale: 25
        })
        break;
         月亮湾
      case "attraction4":
        wx.openLocation({ 
          latitude: 32.098281,
          longitude: 118.906639,
          scale: 25
        })
        break;
        * /
      /*食堂*/
      case "canteen1":
        wx.openLocation({ /*使用微信内置地图查看位置*/
          latitude: 32.101976,  /**西区食堂 */
          longitude: 118.907642,
          scale: 25
        })
        break;
      case "canteen2":
        wx.openLocation({ /*使用微信内置地图查看位置*/
          latitude: 32.098400,/**南区食堂*/
          longitude: 118.911531,
          scale: 25
        })
        break;
      case "canteen3":
        wx.openLocation({ /*使用微信内置地图查看位置*/
          latitude: 32.106020,/**东区食堂*/
          longitude: 118.913044,
          scale: 25
        })
        break;
      /*超市*/
      case "supermarket1":
        wx.openLocation({ /*使用微信内置地图查看位置*/
          latitude: 32.101458,  /**西区超市 */
          longitude: 118.908060,
          scale: 25
        })
        break;
      case "supermarket2":
        wx.openLocation({ /*使用微信内置地图查看位置*/
          latitude: 32.105916, /**东区超市*/
          longitude: 118.914433,
          scale: 25
        })
        break;




      /**教学楼 */
      case "teach1":
       /**学明 */
        wx.openLocation({ /*使用微信内置地图查看位置*/
          latitude: 32.102176, 
          longitude: 118.910844,
          scale: 25
        })
        break;
         /**学正楼 */
      case "teach2":
        wx.openLocation({ /*使用微信内置地图查看位置*/
          latitude: 32.102703, 
          longitude: 118.912593,
          scale: 25
        })
        break;
         /**学海楼 */
      case "teach3":
        wx.openLocation({ /*使用微信内置地图查看位置*/
          latitude: 32.102239, 
          longitude: 118.913527,
          scale: 25
        })
        break;
         /**化成楼 */
      case "teach4":
        wx.openLocation({ /*使用微信内置地图查看位置*/
          latitude: 32.100926, 
          longitude: 118.909788,
          scale: 25
        })
        break;
      /**校医院 */
      case "hospital1":
        wx.openLocation({
          latitude: 32.102280,
          longitude: 118.908226,
          scale: 25
        })
        break;
         /**体育中心 */
      case "Sportcenter":
        wx.openLocation({
          latitude: 32.099408, 
          longitude: 118.906531,
          scale: 25
        })
        break;
      /**体育场 */
      /**西区体育 */
      case "playground1":
        wx.openLocation({
          latitude: 32.099976, 
          longitude: 118.908151,
          scale: 25
        })
        break;
        /**东区体育场 */
      case "playground2":
        wx.openLocation({
          latitude: 32.103121, 
          longitude: 118.914669,
          scale: 25
        })
        break;
      /**图书馆*/
      case "library1":
        wx.openLocation({
          latitude: 32.103544, /**图书馆 */
          longitude: 118.911182,
          scale: 25
        })
        break;
      /**宿舍楼*/
      case "dorm1":
        wx.openLocation({
          latitude: 32.101299,   /**西区学生公寓1 */
          longitude: 118.907926,
          scale: 25
        })
        break;
      case "dorm2":
        wx.openLocation({
          latitude: 32.099004, /**南区学生公寓2 */
          longitude: 118.911724,
          scale: 25
        })
        break;
      case "dorm3":
        wx.openLocation({
          latitude: 32.105420,   /**东区学生公寓3 */
          longitude: 118.914133,

          scale: 25
        })
        break;
      case "dorm4":
        wx.openLocation({
          latitude: 32.117298,
   /**北区学生公寓4 */
          longitude: 118.910050,
          scale: 25
        })
        break;
    }
  }
})
